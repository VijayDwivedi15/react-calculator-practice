export default function (variables) {
  return {
    '.app__sidebar': {
      width: variables.layout.sidebarWidth
    }
  }
}
