export default function (variables) {
  return {
    '.author__github': {
      minWidth: '16px',
      minHeight: '16px'
    },
    '.author__tweet': {
      minWidth: '68px',
      minHeight: '29px'
    }
  }
}
