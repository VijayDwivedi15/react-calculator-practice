export default function (variables) {
  return {
    '.index-sidebar__logo': {
      margin: 0,
      fontSize: '224px',
      lineHeight: '176px',
      color: variables.colors.logo,
      userSelect: 'none'
    }
  }
}
