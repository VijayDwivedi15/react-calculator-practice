export default function (variables) {
  return {
    '.theme-selector__icon': {
      fontSize: variables.fontSizes.button
    }
  }
}
