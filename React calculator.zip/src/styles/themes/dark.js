export default {
  primaryColor: '#16a085',
  accentColor: '#FAAB22',
  accent2Color: '#EE213D',
  canvasColor: '#27313E',
  primaryContrastColor: 'white',
  accentContrastColor: 'white'
}
