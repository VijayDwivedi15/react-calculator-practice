export default function (input, output, isError = false) {
  return {
    input,
    output,
    isError
  }
}
